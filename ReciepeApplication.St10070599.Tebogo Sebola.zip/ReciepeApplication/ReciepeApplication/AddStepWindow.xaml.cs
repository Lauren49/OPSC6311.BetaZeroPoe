﻿using System.Collections.ObjectModel;
using System.Windows;

namespace RecipeApp
{
    public partial class AddStepWindow : Window
    {
        private ObservableCollection<Step> Steps { get; }

        public AddStepWindow(ObservableCollection<Step> steps)
        {
            InitializeComponent();
            Steps = steps;
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            var step = new Step(Steps.Count + 1, StepDescriptionTextBox.Text);
            Steps.Add(step);
            Close();
        }
    }
}
