﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace RecipeApp
{
    public partial class FilterRecipesWindow : Window
    {
        private ObservableCollection<Recipe> Recipes { get; }

        public FilterRecipesWindow(ObservableCollection<Recipe> recipes)
        {
            InitializeComponent();
            Recipes = recipes;
        }

        private void ApplyFilters_Click(object sender, RoutedEventArgs e)
        {
            var filteredRecipes = Recipes.Where(r =>
                r.Ingredients.Any(i => i.Name.ToLower().Contains(IngredientNameTextBox.Text.ToLower())) &&
                (FoodGroupTextBox.Text == "" || r.Ingredients.Any(i => i.FoodGroup.ToLower() == FoodGroupTextBox.Text.ToLower())) &&
                r.Ingredients.Sum(i => i.Calories) <= MaxCaloriesSlider.Value
            ).ToList();

            MessageBox.Show($"Filtered Recipes: {string.Join(", ", filteredRecipes.Select(r => r.Name))}");
        }
    }
}
