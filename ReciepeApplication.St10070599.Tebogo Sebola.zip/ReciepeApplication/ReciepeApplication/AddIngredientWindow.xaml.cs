﻿using System.Collections.ObjectModel;
using System.Windows;

namespace RecipeApp
{
    public partial class AddIngredientWindow : Window
    {
        private ObservableCollection<Ingredient> Ingredients { get; }

        public AddIngredientWindow(ObservableCollection<Ingredient> ingredients)
        {
            InitializeComponent();
            Ingredients = ingredients;
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            var ingredient = new Ingredient(
                IngredientNameTextBox.Text,
                double.Parse(QuantityTextBox.Text),
                UnitTextBox.Text,
                int.Parse(CaloriesTextBox.Text),
                FoodGroupTextBox.Text);
            Ingredients.Add(ingredient);
            Close();
        }
    }
}
