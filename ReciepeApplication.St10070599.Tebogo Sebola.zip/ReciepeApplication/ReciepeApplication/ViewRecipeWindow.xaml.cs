﻿using System.Windows;
using System.Windows;

namespace RecipeApp
{
    public partial class ViewRecipeWindow : Window
    {
        public ViewRecipeWindow(Recipe recipe)
        {
            InitializeComponent();
            DataContext = recipe;
            IngredientsListView.ItemsSource = recipe.Ingredients;
            StepsListView.ItemsSource = recipe.Steps;
            TotalCaloriesTextBlock.Text = $"Total Calories: {recipe.Ingredients.Sum(i => i.Calories)}";
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
