﻿using ReciepeApplication;
using System.Collections.ObjectModel;
using System.Windows;

namespace RecipeApp
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Recipe> Recipes { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Recipes = new ObservableCollection<Recipe>();
            RecipeListView.ItemsSource = Recipes;
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Open Add Recipe Window
        }

        private void ViewRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Open View Recipe Window
        }

        private void FilterRecipes_Click(object sender, RoutedEventArgs e)
        {
            // Open Filter Recipes Window
        }
    }
}

