﻿using System.Collections.ObjectModel;
using System.Windows;

namespace RecipeApp
{
    public partial class AddRecipeWindow : Window
    {
        public ObservableCollection<Ingredient> Ingredients { get; set; }
        public ObservableCollection<Step> Steps { get; set; }
        private ObservableCollection<Recipe> Recipes { get; }

        public AddRecipeWindow(ObservableCollection<Recipe> recipes)
        {
            InitializeComponent();
            Ingredients = new ObservableCollection<Ingredient>();
            Steps = new ObservableCollection<Step>();
            IngredientsListView.ItemsSource = Ingredients;
            StepsListView.ItemsSource = Steps;
            Recipes = recipes;
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            var addIngredientWindow = new AddIngredientWindow(Ingredients);
            addIngredientWindow.Show();
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            var addStepWindow = new AddStepWindow(Steps);
            addStepWindow.Show();
        }

        private void SaveRecipe_Click(object sender, RoutedEventArgs e)
        {
            var recipe = new Recipe
            {
                Name = RecipeNameTextBox.Text,
                Ingredients = Ingredients.ToList(),
                Steps = Steps.ToList()
            };
            Recipes.Add(recipe);
            Close();
        }
    }
}

