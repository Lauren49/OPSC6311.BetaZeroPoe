﻿public class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
    public int Calories { get; set; }
    public string FoodGroup { get; set; }
    public double OriginalQuantity { get; set; }

    public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
    {
        Name = name;
        Quantity = quantity;
        Unit = unit;
        Calories = calories;
        FoodGroup = foodGroup;
        OriginalQuantity = quantity;
    }
}

public class Step
{
    public int Number { get; set; }
    public string Description { get; set; }

    public Step(int number, string description)
    {
        Number = number;
        Description = description;
    }
}

public class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }
    public List<Step> Steps { get; set; }

    public Recipe()
    {
        Name = "";
        Ingredients = new List<Ingredient>();
        Steps = new List<Step>();
    }

    public void ScaleIngredients(double factor)
    {
        foreach (Ingredient ingredient in Ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }

    public void ResetQuantities()
    {
        foreach (Ingredient ingredient in Ingredients)
        {
            ingredient.Quantity = ingredient.OriginalQuantity;
        }
    }

    public void ClearData()
    {
        Name = "";
        Ingredients = new List<Ingredient>();
        Steps = new List<Step>();
    }
}
