package com.example.additems3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class searchBookToEdit : AppCompatActivity() {

    lateinit var searchBar : EditText
    lateinit var searchBtn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_book_to_edit)

        searchBar = findViewById(R.id.titleToEdit)
        searchBtn = findViewById(R.id.buttonSearch)

        searchBtn.setOnClickListener {
            val titleToSearch = searchBar.text.toString()

            // Query Firebase for the book with the entered title
            val database = FirebaseDatabase.getInstance()
            val ref = database.getReference("Book")
            ref.orderByChild("title").equalTo(titleToSearch).addListenerForSingleValueEvent(object :
                ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Navigate to itemsEdit with the book's details
                        for (postSnapshot in snapshot.children) {
                            val bookKey = postSnapshot.key
                            startActivity(Intent(this@searchBookToEdit, itemsEdit::class.java).apply {
                                putExtra("bookKey", bookKey) // Pass the book key to itemsEdit
                            })
                            return
                        }
                    } else {
                        // Handle case where book with given title was not found
                        // Display a message or handle accordingly
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle error
                }
            })
        }
    }
}