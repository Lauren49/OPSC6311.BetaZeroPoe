package com.example.additems3

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    lateinit var addItemBtn : Button
    lateinit var removeItemBtn : Button
    lateinit var editItemBtn : Button
    private lateinit var btnArrowBack : FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        addItemBtn = findViewById(R.id.addItemID)
        removeItemBtn = findViewById(R.id.removeItemID)
        editItemBtn = findViewById(R.id.editItemID)
        btnArrowBack = findViewById(R.id.backFloat1)

        addItemBtn.setOnClickListener(View.OnClickListener { startActivity(Intent(this, itemsAdd::class.java)) })
        removeItemBtn.setOnClickListener(View.OnClickListener { startActivity(Intent(this, itemsRemove::class.java)) })
        editItemBtn.setOnClickListener(View.OnClickListener { startActivity(Intent(this, searchBookToEdit::class.java)) })
        btnArrowBack.setOnClickListener {
            startActivity(Intent(this, homepage::class.java))
        }

    }
}