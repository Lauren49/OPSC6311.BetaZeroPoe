package com.example.additems3

data class achievement(
    val id: Int,
    val title: String,
    val description: String,
    val isUnlocked: Boolean,
    val progress: Int
)
