package com.example.additems3

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth

class settings : AppCompatActivity() {

    private lateinit var btnAccountSettings : Button
    private lateinit var btnNotifications : Button
    private lateinit var nameTv : TextView
    private lateinit var sharedPrefs : SharedPreferences
    private lateinit var btnScanner : Button
    private lateinit var btnArrowBack : FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        btnAccountSettings = findViewById(R.id.accountSettings)
        btnNotifications = findViewById(R.id.notifications)
        btnScanner = findViewById(R.id.scanner)
        nameTv = findViewById(R.id.profileName1)

        // Initialize Firebase Authentication instance
        val auth = FirebaseAuth.getInstance()

        btnAccountSettings.setOnClickListener(View.OnClickListener { startActivity(Intent(this, accountSettings::class.java)) })

        btnScanner.setOnClickListener(View.OnClickListener { startActivity(Intent(this, qr::class.java)) })

        btnArrowBack.setOnClickListener(View.OnClickListener { startActivity(Intent(this, homepage::class.java)) })

        // Display current user's name
        val currentUser = auth.currentUser
        if (currentUser != null) {
            nameTv.text = currentUser.displayName
        }



    }
}