package com.example.additems3

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase

class names : AppCompatActivity() {

    lateinit var eFName: EditText
    lateinit var eSName: EditText
    lateinit var btnSave: Button
    lateinit var btnBack: Button
    private lateinit var currentUser: FirebaseUser
    private lateinit var nameTv: TextView
    private lateinit var sharedPrefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_names)

        //EditText
        eFName = findViewById(R.id.firstName)
        eSName = findViewById(R.id.lastName)

        //Button
        btnSave = findViewById(R.id.usernameSave)
        btnBack = findViewById(R.id.usernameBack)
        nameTv = findViewById(R.id.profileName1)

        // Initialize Firebase Authentication instance
        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser

        btnSave.setOnClickListener {
            val newName = eFName.text.toString()

            // Update Firebase Realtime Database
            if (currentUser != null) {
                val userId = currentUser.uid
                val currentUserRef = FirebaseDatabase.getInstance().getReference("User/$userId")
                currentUserRef.child("name").setValue(newName)

                // Update Firebase Authentication display name
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(newName)
                    .build()

                currentUser.updateProfile(profileUpdates)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            // Update UI if needed
                            nameTv.text = newName // Update TextView with new name if necessary
                            // Optionally, you can also update the name in the shared preferences
                            val editor = sharedPrefs.edit()
                            editor.putString("displayName", newName)
                            editor.apply()
                        } else {
                            // Handle update failure
                            // You can log or show an error message
                        }
                    }
            }

            btnBack.setOnClickListener {
                finish() // Close NamesActivity and go back to previous activity
            }
        }
    }
}