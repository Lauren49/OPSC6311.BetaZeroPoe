package com.example.additems3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class login1 : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var signupText: TextView

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login1)

        emailEditText = findViewById(R.id.loginEmail1)
        passwordEditText = findViewById(R.id.loginPassword1)
        loginButton = findViewById(R.id.loginButton1)
        signupText = findViewById(R.id.signupText1)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().getReference("users")

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            // Fetch user data from the database
                            fetchUserData(email, password)
                        } else {
                            Log.e("LoginError", "Authentication failed: ${task.exception?.message}")
                            // Handle login failure (e.g., show a toast or a snackbar)
                        }
                    }
            } else {
                Log.e("LoginError", "Email or Password is empty")
                // Show an error message indicating empty fields
            }
        }

        signupText.setOnClickListener {
            startActivity(Intent(this, signup::class.java))
            finish()
        }
    }

    private fun fetchUserData(email: String, password: String) {
        database.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var userFound = false
                for (userSnapshot in snapshot.children) {
                    val storedPassword = userSnapshot.child("password").value.toString()
                    if (storedPassword == password) {
                        userFound = true
                        // Login successful, navigate to homepage
                        startActivity(Intent(this@login1, homepage::class.java))
                        finish()
                        return
                    }
                }
                if (!userFound) {
                    Log.e("LoginError", "Password does not match")
                    // Handle login failure, show a toast or a snackbar
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("LoginError", "Database error: ${error.message}")
                // Handle database error
            }
        })
    }
}