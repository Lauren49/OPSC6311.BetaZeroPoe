package com.example.additems3

data class Book (
    val title: String = "",
    val author: String = "",
    val releaseDate: String = "",
    val category: String = ""
)