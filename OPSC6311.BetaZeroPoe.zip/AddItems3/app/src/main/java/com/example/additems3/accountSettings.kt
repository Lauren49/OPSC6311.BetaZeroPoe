package com.example.additems3

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth

class accountSettings : AppCompatActivity() {

    private lateinit var btnCProfile : FloatingActionButton
    private lateinit var profilePic : ImageView
    private lateinit var btnChangeName : Button
    private lateinit var nameTv : TextView
    private lateinit var btnPassword : Button
    private lateinit var btnArrowBack : FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_settings)

        btnCProfile = findViewById(R.id.cameraFloatingActionButton)
        profilePic = findViewById(R.id.profileImage2)
        btnChangeName = findViewById(R.id.accountUsername)
        btnPassword = findViewById(R.id.password_change)
        btnArrowBack = findViewById(R.id.backFloat)

        // Initialize Firebase Authentication instance
        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser

        // Display current user's name
        if (currentUser != null) {
            nameTv.text = currentUser.displayName
        }

        btnChangeName.setOnClickListener {
            startActivity(Intent(this, names::class.java))
        }

        btnPassword.setOnClickListener {
            startActivity(Intent(this, passwordChanges::class.java))
        }

        btnArrowBack.setOnClickListener {
            finish() // Close AccountSettingsActivity and go back to previous activity
        }

    }


}