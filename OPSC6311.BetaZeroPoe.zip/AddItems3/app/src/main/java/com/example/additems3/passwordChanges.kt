package com.example.additems3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth

class passwordChanges : AppCompatActivity() {

    private lateinit var oldPasswordEditText: EditText
    private lateinit var newPasswordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var btnSave : Button
    private lateinit var btnBack : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_password_changes)

        btnSave = findViewById(R.id.passwordSave)
        btnBack = findViewById(R.id.passwordBack)
        oldPasswordEditText = findViewById(R.id.oldPassword)
        newPasswordEditText = findViewById(R.id.newPassword)
        confirmPasswordEditText = findViewById(R.id.confirmPassword)

        // Initialize Firebase Authentication instance
        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser

        btnSave.setOnClickListener {
            val newPassword = newPasswordEditText.text.toString()

            // Update Firebase Authentication password
            if (currentUser != null) {
                val email = currentUser.email
                val oldPassword = oldPasswordEditText.text.toString()

                // Re-authenticate user
                val credential = email?.let { it1 -> auth.currentUser?.email?.let { it2 -> EmailAuthProvider.getCredential(it2, oldPassword) } }
                currentUser.reauthenticate(credential!!).addOnCompleteListener {
                    if (it.isSuccessful) {
                        currentUser.updatePassword(newPassword).addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                // Password updated successfully
                                finish() // Close PasswordChangesActivity and go back to previous activity
                            } else {
                                // Handle password update failure
                            }
                        }
                    } else {
                        // Handle re-authentication failure
                    }
                }
            }
        }

        btnBack.setOnClickListener {
            finish() // Close PasswordChangesActivity and go back to previous activity
        }
    }
}