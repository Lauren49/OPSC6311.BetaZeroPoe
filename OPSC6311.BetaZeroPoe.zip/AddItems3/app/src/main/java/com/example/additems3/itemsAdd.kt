package com.example.additems3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class itemsAdd : AppCompatActivity() {

    lateinit var categoryText : EditText
    lateinit var yearAcquiredText : EditText
    lateinit var bookTitleText : EditText
    lateinit var authorText : EditText
    lateinit var releaseYearText: EditText
    lateinit var imageUrlText : EditText
    lateinit var bookDescText : EditText
    lateinit var saveBtn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_items_add)

        categoryText = findViewById(R.id.category)
        yearAcquiredText = findViewById(R.id.acquiredDate)
        bookTitleText = findViewById(R.id.bookTitle)
        authorText = findViewById(R.id.bookAuthor)
        releaseYearText = findViewById(R.id.releaseYear)
        imageUrlText = findViewById(R.id.imageUrl)
        bookDescText = findViewById(R.id.bookDescription)
        saveBtn = findViewById(R.id.buttonSave)

        saveBtn.setOnClickListener{
            // Collect user inputs
            val category = categoryText.text.toString()
            val yearAcquired = yearAcquiredText.text.toString()
            val bookTitle = bookTitleText.text.toString()
            val author = authorText.text.toString()
            val releaseYear = releaseYearText.text.toString()
            val imageUrl = imageUrlText.text.toString()
            val bookDesc = bookDescText.text.toString()

            // Save to Firebase Realtime Database
            val database = FirebaseDatabase.getInstance()
            val myRef = database.getReference("Book").push()

            val bookData = hashMapOf(
                "category" to category,
                "year acquired" to yearAcquired,
                "title" to bookTitle,
                "author" to author,
                "release date" to releaseYear,
                "imageURL" to imageUrl,
                "description" to bookDesc
            )

            myRef.setValue(bookData)

            // Return to MainActivity
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}