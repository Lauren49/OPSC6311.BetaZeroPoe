package com.example.additems3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class categories : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var booksAdapter: BooksAdapter
    private lateinit var database: DatabaseReference
    private var booksList: MutableList<Book> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categories)

        recyclerView = findViewById(R.id.recyclerViewBooks)
        recyclerView.layoutManager = LinearLayoutManager(this)
        booksAdapter = BooksAdapter(booksList)
        recyclerView.adapter = booksAdapter

        val category = intent.getStringExtra("CATEGORY") ?: ""
        Log.d("CategoriesActivity", "Category: $category")

        database = FirebaseDatabase.getInstance().getReference("books")

        database.orderByChild("category").equalTo(category).addValueEventListener(object :
            ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                booksList.clear()
                for (bookSnapshot in snapshot.children) {
                    val book = bookSnapshot.getValue(Book::class.java)
                    if (book != null) {
                        booksList.add(book)
                        Log.d("CategoriesActivity", "Book added: ${book.title}")
                    }
                }
                booksAdapter.notifyDataSetChanged()
                Log.d("CategoriesActivity", "Books List Size: ${booksList.size}")
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("CategoriesActivity", "Database Error: ${error.message}")
                // Handle error
            }
        })
    }
    }
