package com.example.additems3

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.games.achievement.Achievement

class AchievementsAdapter(private val achievements: List<Achievement>) :
    RecyclerView.Adapter<AchievementsAdapter.AchievementViewHolder>() {

    class AchievementViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.tvAchievementTitle)
        val descriptionTextView: TextView = itemView.findViewById(R.id.tvAchievementDescription)
        val progressBar: ProgressBar = itemView.findViewById(R.id.pbAchievementProgress)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AchievementViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.achievement_items, parent, false)
        return AchievementViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: AchievementViewHolder, position: Int) {
        val currentAchievement = achievements[position]
        holder.descriptionTextView.text = currentAchievement.description
    }

    override fun getItemCount() = achievements.size
}