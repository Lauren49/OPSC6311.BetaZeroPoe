package com.example.additems3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class itemsEdit : AppCompatActivity() {

    lateinit var categoryText : EditText
    lateinit var yearAcquiredText : EditText
    lateinit var bookTitleText : EditText
    lateinit var authorText : EditText
    lateinit var releaseYearText: EditText
    lateinit var imageUrlText : EditText
    lateinit var bookDescText : EditText
    lateinit var changeBtn : Button
    lateinit var bookKey: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_items_edit)

        categoryText = findViewById(R.id.categoryC)
        yearAcquiredText = findViewById(R.id.acquiredDateC)
        bookTitleText = findViewById(R.id.bookTitleC)
        authorText = findViewById(R.id.bookAuthorC)
        releaseYearText = findViewById(R.id.releaseYearC)
        imageUrlText = findViewById(R.id.imageUrlC)
        bookDescText = findViewById(R.id.bookDescriptionC)
        changeBtn = findViewById(R.id.buttonChange)

        // Retrieve book key from intent extras
        bookKey = intent.getStringExtra("bookKey") ?: ""

        // Populate EditTexts with current book details (optional, based on your design)

        changeBtn.setOnClickListener {
            // Update edited details in Firebase
            val database = FirebaseDatabase.getInstance()
            val myRef = database.getReference("Book").child(bookKey)

            val updatedData = hashMapOf(
                "category" to categoryText.text.toString(),
                "year acquired" to yearAcquiredText.text.toString(),
                "title" to bookTitleText.text.toString(),
                "author" to authorText.text.toString(),
                "release date" to releaseYearText.text.toString(),
                "imageURL" to imageUrlText.text.toString(),
                "description" to bookDescText.text.toString()
            )

            myRef.setValue(updatedData)

            // Return to MainActivity
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}