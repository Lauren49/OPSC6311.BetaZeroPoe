package com.example.additems3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ProgressBar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.games.achievement.Achievement

class AchievementsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_achievements)



//        val achievements = listOf(
//            Achievement(1, "First Comic Collected", "Collect your first comic book", true, 100),
//            Achievement(2, "Collection Starter", "Collect 10 comic books", false, 50)
//        )
//
//        val recyclerView: RecyclerView = findViewById(R.id.rvAchievements)
//        recyclerView.layoutManager = LinearLayoutManager(this)
//        recyclerView.adapter = AchievementsAdapter(achievements)
//
//        val overallProgress = calculateOverallProgress(achievements)
//        val progressBar: ProgressBar = findViewById(R.id.achievementProgressBar)
//        progressBar.progress = overallProgress
//    }
//
//    private fun calculateOverallProgress(achievements: List<Achievement>): Int {
//        val totalProgress = achievements.sumOf { it.progress }
//        return totalProgress / achievements.size
//    }
  }
}