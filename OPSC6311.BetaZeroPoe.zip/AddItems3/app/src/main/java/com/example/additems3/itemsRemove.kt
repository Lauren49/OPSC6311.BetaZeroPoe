package com.example.additems3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class itemsRemove : AppCompatActivity() {

    lateinit var title : EditText
    lateinit var removeBtn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_items_remove)

        removeBtn = findViewById(R.id.buttonRemove)
        title = findViewById(R.id.TitleToRemove)

        removeBtn.setOnClickListener {
            val titleToRemove = title.text.toString()

            // Query Firebase for the book with the entered title to get its key
            val database = FirebaseDatabase.getInstance()
            val ref = database.getReference("Book")

            ref.orderByChild("title").equalTo(titleToRemove)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            for (postSnapshot in snapshot.children) {
                                val bookKey = postSnapshot.key
                                // Remove the book from Firebase
                                if (bookKey != null) {
                                    ref.child(bookKey).removeValue()
                                }
                                break
                            }
                        } else {
                            // Handle case where book with given title was not found
                            // Display a message or handle accordingly
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        // Handle error
                    }
                })

            // Return to MainActivity
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}